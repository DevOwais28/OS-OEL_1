#!/bin/bash

LAB_DIR="./lab"
ARCHIVE_DIR="./archives"

mkdir -p "$LAB_DIR" "$ARCHIVE_DIR"

while true
do
    echo ""
    echo "===== MENU ====="
    echo "1. Create workspace"
    echo "2. Check usage"
    echo "3. Search file"
    echo "4. Archive old workspaces"
    echo "5. Exit"
    echo "================"

    read -p "Enter choice: " choice

    if [ "$choice" = "1" ]; then
        read -p "Enter username: " user
        path="$LAB_DIR/$user"

        if [ -d "$path" ]; then
            echo "User already exists"
        else
            mkdir -p "$path/docs" "$path/code"
            echo "Workspace created"
        fi

    elif [ "$choice" = "2" ]; then
        read -p "Enter username: " user
        path="$LAB_DIR/$user"

        if [ -d "$path" ]; then
            size=$(du -s "$path" | cut -f1)
            echo "Usage: $size KB"

            if [ "$size" -gt 102400 ]; then
                echo "Warning: Over 100MB"
            fi
        else
            echo "User not found"
        fi

    elif [ "$choice" = "3" ]; then
        read -p "Enter file name: " name
        find "$LAB_DIR" -name "*$name*" 2>/dev/null

    
    elif [ "$choice" = "4" ]; then
        echo "Checking old folders..."

        for path in "$LAB_DIR"/*
        do
            [ -d "$path" ] || continue

            user=$(basename "$path")

            last=$(stat -c %Y "$path" 2>/dev/null)
            now=$(date +%s)

            days=$(( (now - last) / 86400 ))

            if [ "$days" -gt 60 ]; then
                echo "Archiving $user ($days days old)"

                tar -czf "$ARCHIVE_DIR/$user.tar.gz" -C "$LAB_DIR" "$user"

                read -p "Delete it? (y/n): " ans
                if [ "$ans" = "y" ]; then
                    rm -rf "$path"
                    echo "Deleted $user"
                fi
            fi
        done

    elif [ "$choice" = "5" ]; then
        echo "Bye!"
        break

    else
        echo "Invalid option"
    fi

done